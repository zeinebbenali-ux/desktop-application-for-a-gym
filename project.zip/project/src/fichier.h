#ifndef FICHIER_H
#define FICHIER_H

#include <gtk/gtk.h>
#include <glib.h>


extern GList *g_cours;
extern char g_cours_filepath[256];
extern char g_current_member_id[50];

/* Structure cours */
typedef struct {
    int identifiant;
    char Nom[50];
    char coach[50];
    char centre[50];
    char salle[30];
    char date[20];
    char heure[10];
    float prix;
    int nombre_de_places;
    char statut[20];
} cours;


void ajouter_cours(cours c);
cours recuperer_saisie(GtkWidget *from_widget);
GList* load_cours_from_file(const char *filename);
void save_cours_to_file(GList *cours_list, const char *filename);
void afficher_cours(GtkWidget *liste);
void delete_cours_from_list(GList **cours_list, int id);
cours* find_cours_by_id(GList *cours_list, int id);
void init_cours_choix_interface(GtkWidget *tree);
void free_cours_list(GList *list);

#endif
