#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "coaches.h"

/* Créer un nouveau coach */
Coach* create_coach(const char *id, const char *nom, const char *specialite,
                   const char *disponibilite, const char *telephone)
{
    Coach *coach = (Coach *)malloc(sizeof(Coach));
    if (!coach) {
        g_warning("Erreur : allocation mémoire échouée");
        return NULL;
    }

    strncpy(coach->id, id, sizeof(coach->id) - 1);
    coach->id[sizeof(coach->id) - 1] = '\0';

    strncpy(coach->nom, nom, sizeof(coach->nom) - 1);
    coach->nom[sizeof(coach->nom) - 1] = '\0';

    strncpy(coach->specialite, specialite, sizeof(coach->specialite) - 1);
    coach->specialite[sizeof(coach->specialite) - 1] = '\0';

    strncpy(coach->disponibilite, disponibilite, sizeof(coach->disponibilite) - 1);
    coach->disponibilite[sizeof(coach->disponibilite) - 1] = '\0';

    strncpy(coach->telephone, telephone, sizeof(coach->telephone) - 1);
    coach->telephone[sizeof(coach->telephone) - 1] = '\0';

    return coach;
}

/* Ajouter un coach à la liste */
void add_coach_to_list(GList **list, Coach *coach)
{
    if (!coach) {
        g_warning("Erreur : coach NULL");
        return;
    }
    *list = g_list_append(*list, coach);
    g_print("✔ Coach ajouté : %s\n", coach->nom);
}

/* Charger les coaches depuis le fichier */
void load_coaches_from_file(GList **list, const char *filepath)
{
    FILE *file = fopen(filepath, "r");
    if (!file) {
        g_print("⚠ Fichier %s non trouvé\n", filepath);
        return;
    }

    char line[512];
    while (fgets(line, sizeof(line), file)) {
        /* Ignorer les lignes vides */
        if (line[0] == '\n' || line[0] == '\0')
            continue;

        /* Supprimer le newline */
        line[strcspn(line, "\n")] = '\0';

        Coach *coach = (Coach *)malloc(sizeof(Coach));
        if (!coach) {
            g_warning("Erreur : allocation mémoire échouée");
            continue;
        }

        /* Format : id|nom|specialite|disponibilite|telephone */
        if (sscanf(line, "%49[^|]|%99[^|]|%99[^|]|%199[^|]|%19[^|]",
                   coach->id,
                   coach->nom,
                   coach->specialite,
                   coach->disponibilite,
                   coach->telephone) == 5) {
            *list = g_list_append(*list, coach);
        } else {
            g_warning("⚠ Ligne invalide : %s", line);
            free(coach);
        }
    }

    fclose(file);
    g_print("✔ %d coaches chargés depuis %s\n", g_list_length(*list), filepath);
}

/* Libérer la mémoire d'un coach */
void free_coach(Coach *coach)
{
    if (coach)
        free(coach);
}

/* Libérer la mémoire de la liste complète */
void free_coaches_list(GList *list)
{
    for (GList *iter = list; iter != NULL; iter = iter->next) {
        free_coach((Coach *)iter->data);
    }
    g_list_free(list);
}
