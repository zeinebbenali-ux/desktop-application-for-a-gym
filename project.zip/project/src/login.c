/* login.c */
#include <string.h>
#include "login.h"

void traiter_login(char identifiant[], char motdepasse[], char resultat[])
{
    /* Exemple simple : un seul couple login/mot de passe accepté */
    if (strcmp(identifiant, "admin") == 0 && strcmp(motdepasse, "1234") == 0)
    {
        strcpy(resultat, "Bienvenue ");
        strcat(resultat, identifiant);
    }
    else
    {
        strcpy(resultat, "Identifiant ou mot de passe incorrect");
    }
}

