#ifndef CENTRE_REQUESTS_H
#define CENTRE_REQUESTS_H

#include <gtk/gtk.h>

/* Structure pour une demande d'inscription entraineur à centre */
typedef struct {
    char id_demande[50];
    char id_entraineur[50];
    char id_centre[50];
    char nom_centre[100];
    char date_demande[20];
    char statut[20];  /* "en attente", "acceptée", "refusée" */
} CentreRequest;

/* Fonctions CRUD */
GList* load_centre_requests_from_file(const char *filename);
void save_centre_requests_to_file(GList *requests, const char *filename);
CentreRequest* create_centre_request(const char *id_demande, const char *id_entraineur, const char *id_centre, const char *nom_centre, const char *date_demande, const char *statut);
void add_centre_request_to_list(GList **requests, CentreRequest *request);
void delete_centre_request_from_list(GList **requests, const char *id_demande);
CentreRequest* find_centre_request_by_id(GList *requests, const char *id_demande);
void free_centre_requests_list(GList *requests);

#endif
