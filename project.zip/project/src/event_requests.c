#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <glib.h>
#include "event_requests.h"

/* ===== GLOBALS ===== */
GList *g_event_requests = NULL;
const char *g_event_requests_filepath = "event_requests.txt";

/* ===== CREATE ===== */
EventRequest* create_event_request(
    const char *id_membre,
    const char *id_evenement,
    const char *nom_evenement,
    const char *date_inscription
) {
    EventRequest *req = malloc(sizeof(EventRequest));
    if (!req) return NULL;

    snprintf(req->id_demande, sizeof(req->id_demande),
             "ER_%ld", time(NULL));

    strncpy(req->id_membre, id_membre, sizeof(req->id_membre) - 1);
    strncpy(req->id_evenement, id_evenement, sizeof(req->id_evenement) - 1);
    strncpy(req->nom_evenement, nom_evenement, sizeof(req->nom_evenement) - 1);
    strncpy(req->date_inscription, date_inscription, sizeof(req->date_inscription) - 1);

    strcpy(req->statut, "en attente");
    return req;
}

/* ===== LOAD ===== */
void load_event_requests_from_file(GList **list, const char *filepath)
{
    FILE *f = fopen(filepath, "r");
    if (!f) return;

    char line[512];
    while (fgets(line, sizeof(line), f)) {
        EventRequest *req = malloc(sizeof(EventRequest));
        if (!req) continue;

        if (sscanf(line,
            "%49[^|]|%49[^|]|%49[^|]|%99[^|]|%19[^|]|%19[^|]",
            req->id_demande,
            req->id_membre,
            req->id_evenement,
            req->nom_evenement,
            req->date_inscription,
            req->statut) == 6)
        {
            *list = g_list_append(*list, req);
        } else {
            free(req);
        }
    }
    fclose(f);
}

/* ===== SAVE ===== */
void save_event_requests_to_file(GList *list, const char *filepath)
{
    FILE *f = fopen(filepath, "w");
    if (!f) return;

    for (GList *l = list; l; l = l->next) {
        EventRequest *r = l->data;
        fprintf(f, "%s|%s|%s|%s|%s|%s\n",
            r->id_demande,
            r->id_membre,
            r->id_evenement,
            r->nom_evenement,
            r->date_inscription,
            r->statut);
    }
    fclose(f);
}

/* ===== DELETE ===== */
void delete_event_request_from_list(GList **list, const char *id_demande)
{
    for (GList *l = *list; l; l = l->next) {
        EventRequest *r = l->data;
        if (strcmp(r->id_demande, id_demande) == 0) {
            *list = g_list_remove(*list, r);
            free(r);
            return;
        }
    }
}

/* ===== FREE ===== */
void free_event_request(EventRequest *req)
{
    if (req) free(req);
}

void free_event_requests_list(GList *list)
{
    for (GList *l = list; l; l = l->next)
        free_event_request(l->data);
    g_list_free(list);
}

