#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "equipment.h"

/* ============================================================================
   FONCTIONS POUR ÉQUIPEMENTS
   ============================================================================ */

/**
 * Charge les équipements depuis un fichier
 * Format: id|code_barre|type|marque|centre|disponibilite
 */
GList* load_equipments(const char *filepath)
{
    FILE *file = fopen(filepath, "r");
    if (!file) {
        g_warning("⚠️ Impossible d'ouvrir %s", filepath);
        return NULL;
    }

    GList *equipments = NULL;
    char line[512];

    while (fgets(line, sizeof(line), file)) {
        /* Supprimer le newline */
        line[strcspn(line, "\n")] = 0;

        if (strlen(line) == 0) continue;

        /* Parser la ligne */
        char id[50], code_barre[100], type[100], marque[100], centre[100], disponibilite[50];
        if (sscanf(line, "%49[^|]|%99[^|]|%99[^|]|%99[^|]|%99[^|]|%49[^\n]",
                   id, code_barre, type, marque, centre, disponibilite) == 6) {
            Equipment *eq = create_equipment(id, code_barre, type, marque, centre, disponibilite);
            equipments = g_list_append(equipments, eq);
        }
    }

    fclose(file);
    return equipments;
}

/**
 * Sauvegarde les équipements dans un fichier
 */
void save_equipments(GList *equipments, const char *filepath)
{
    FILE *file = fopen(filepath, "w");
    if (!file) {
        g_warning("⚠️ Impossible d'écrire dans %s", filepath);
        return;
    }

    for (GList *iter = equipments; iter; iter = iter->next) {
        Equipment *eq = (Equipment *)iter->data;
        fprintf(file, "%s|%s|%s|%s|%s|%s\n",
                eq->id, eq->code_barre, eq->type, eq->marque, eq->centre, eq->disponibilite);
    }

    fclose(file);
}

/**
 * Crée une nouvelle structure Equipment
 */
Equipment* create_equipment(const char *id, const char *code_barre, const char *type,
                           const char *marque, const char *centre, const char *disponibilite)
{
    Equipment *eq = g_malloc(sizeof(Equipment));
    strncpy(eq->id, id, sizeof(eq->id) - 1);
    strncpy(eq->code_barre, code_barre, sizeof(eq->code_barre) - 1);
    strncpy(eq->type, type, sizeof(eq->type) - 1);
    strncpy(eq->marque, marque, sizeof(eq->marque) - 1);
    strncpy(eq->centre, centre, sizeof(eq->centre) - 1);
    strncpy(eq->disponibilite, disponibilite, sizeof(eq->disponibilite) - 1);
    return eq;
}

/**
 * Libère la mémoire d'un équipement
 */
void free_equipment(Equipment *eq)
{
    if (eq) g_free(eq);
}

/**
 * Libère la liste d'équipements
 */
void free_equipments_list(GList *equipments)
{
    g_list_free_full(equipments, (GDestroyNotify)free_equipment);
}

/**
 * Cherche un équipement par code barre
 */
Equipment* find_equipment_by_code(GList *equipments, const char *code_barre)
{
    for (GList *iter = equipments; iter; iter = iter->next) {
        Equipment *eq = (Equipment *)iter->data;
        if (strcmp(eq->code_barre, code_barre) == 0) {
            return eq;
        }
    }
    return NULL;
}

/**
 * Cherche un équipement par ID
 */
Equipment* find_equipment_by_id(GList *equipments, const char *id)
{
    for (GList *iter = equipments; iter; iter = iter->next) {
        Equipment *eq = (Equipment *)iter->data;
        if (strcmp(eq->id, id) == 0) {
            return eq;
        }
    }
    return NULL;
}

/* ============================================================================
   FONCTIONS POUR RÉSERVATIONS
   ============================================================================ */

/**
 * Charge les réservations depuis un fichier
 * Format: id_reservation|code_barre|id_entraineur|jour|creneau|date
 */
GList* load_reservations(const char *filepath)
{
    FILE *file = fopen(filepath, "r");
    if (!file) {
        g_warning("⚠️ Impossible d'ouvrir %s", filepath);
        return NULL;
    }

    GList *reservations = NULL;
    char line[512];

    while (fgets(line, sizeof(line), file)) {
        /* Supprimer le newline */
        line[strcspn(line, "\n")] = 0;

        if (strlen(line) == 0) continue;

        /* Parser la ligne */
        char id_reservation[50], code_barre[100], id_entraineur[50], jour[50], creneau[50], date[20];
        if (sscanf(line, "%49[^|]|%99[^|]|%49[^|]|%49[^|]|%49[^|]|%19[^\n]",
                   id_reservation, code_barre, id_entraineur, jour, creneau, date) == 6) {
            Reservation *res = create_reservation(id_reservation, code_barre, id_entraineur, jour, creneau, date);
            reservations = g_list_append(reservations, res);
        }
    }

    fclose(file);
    return reservations;
}

/**
 * Sauvegarde les réservations dans un fichier
 */
void save_reservations(GList *reservations, const char *filepath)
{
    FILE *file = fopen(filepath, "w");
    if (!file) {
        g_warning("⚠️ Impossible d'écrire dans %s", filepath);
        return;
    }

    for (GList *iter = reservations; iter; iter = iter->next) {
        Reservation *res = (Reservation *)iter->data;
        fprintf(file, "%s|%s|%s|%s|%s|%s\n",
                res->id_reservation, res->code_barre, res->id_entraineur,
                res->jour, res->creneau, res->date);
    }

    fclose(file);
}

/**
 * Crée une nouvelle structure Reservation
 */
Reservation* create_reservation(const char *id_reservation, const char *code_barre,
                               const char *id_entraineur, const char *jour,
                               const char *creneau, const char *date)
{
    Reservation *res = g_malloc(sizeof(Reservation));
    strncpy(res->id_reservation, id_reservation, sizeof(res->id_reservation) - 1);
    strncpy(res->code_barre, code_barre, sizeof(res->code_barre) - 1);
    strncpy(res->id_entraineur, id_entraineur, sizeof(res->id_entraineur) - 1);
    strncpy(res->jour, jour, sizeof(res->jour) - 1);
    strncpy(res->creneau, creneau, sizeof(res->creneau) - 1);
    strncpy(res->date, date, sizeof(res->date) - 1);
    return res;
}

/**
 * Libère la mémoire d'une réservation
 */
void free_reservation(Reservation *res)
{
    if (res) g_free(res);
}

/**
 * Libère la liste de réservations
 */
void free_reservations_list(GList *reservations)
{
    g_list_free_full(reservations, (GDestroyNotify)free_reservation);
}

/**
 * Vérifie si un équipement est disponible pour un jour et créneau donnés
 */
gboolean is_equipment_available(GList *reservations, const char *code_barre,
                               const char *jour, const char *creneau)
{
    for (GList *iter = reservations; iter; iter = iter->next) {
        Reservation *res = (Reservation *)iter->data;
        if (strcmp(res->code_barre, code_barre) == 0 &&
            strcmp(res->jour, jour) == 0 &&
            strcmp(res->creneau, creneau) == 0) {
            return FALSE;  /* Déjà réservé */
        }
    }
    return TRUE;  /* Disponible */
}

/**
 * Récupère les réservations d'un entraineur
 */
GList* get_reservations_by_trainer(GList *reservations, const char *id_entraineur)
{
    GList *trainer_reservations = NULL;
    for (GList *iter = reservations; iter; iter = iter->next) {
        Reservation *res = (Reservation *)iter->data;
        if (strcmp(res->id_entraineur, id_entraineur) == 0) {
            trainer_reservations = g_list_append(trainer_reservations, res);
        }
    }
    return trainer_reservations;
}
