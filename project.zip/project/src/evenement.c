#include <stdio.h>
#include "evenement.h"

void ajouter_evenement(evenement e)
{
    FILE *f = fopen("evenement.txt", "a+");
    if(f != NULL)
    {
        fprintf(f, "%s %s %s %d %.2f %s %s %s %s\n",
                e.id, e.nom, e.coach, e.nb_places, e.prix,
                e.heure, e.salle, e.periode, e.statut);
        fclose(f);
    }
}

