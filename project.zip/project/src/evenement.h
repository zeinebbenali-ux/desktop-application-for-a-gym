#ifndef EVENEMENT_H_INCLUDED
#define EVENEMENT_H_INCLUDED

typedef struct {
    char id[20];
    char nom[50];
    char coach[50];
    int nb_places;
    float prix;
    char heure[20];
    char salle[20];
    char periode[20];
    char statut[20];
} evenement;

void ajouter_evenement(evenement e);

#endif

