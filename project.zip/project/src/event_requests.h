#ifndef EVENT_REQUESTS_H
#define EVENT_REQUESTS_H

#include <glib.h>

/* ===== STRUCT INSCRIPTION EVENEMENT ===== */
typedef struct {
    char id_demande[50];
    char id_membre[50];
    char id_evenement[50];
    char nom_evenement[100];
    char date_inscription[20];
    char statut[20];   /* en attente | acceptée | refusée */
} EventRequest;

/* ===== CRUD ===== */
EventRequest* create_event_request(
    const char *id_membre,
    const char *id_evenement,
    const char *nom_evenement,
    const char *date_inscription
);

void load_event_requests_from_file(GList **list, const char *filepath);
void save_event_requests_to_file(GList *list, const char *filepath);
void delete_event_request_from_list(GList **list, const char *id_demande);
void free_event_request(EventRequest *req);
void free_event_requests_list(GList *list);

/* ===== GLOBALS ===== */
extern GList *g_event_requests;
extern const char *g_event_requests_filepath;

#endif

