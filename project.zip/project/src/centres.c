#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "centres.h"

/* Charger les centres depuis le fichier */
GList* load_centres_from_file(const char *filename)
{
    FILE *file = fopen(filename, "r");
    if (!file) {
        g_warning("Impossible d'ouvrir le fichier %s", filename);
        return NULL;
    }

    GList *centres = NULL;
    char line[512];

    while (fgets(line, sizeof(line), file)) {
        /* Supprimer le saut de ligne */
        line[strcspn(line, "\n")] = 0;

        if (strlen(line) == 0) continue;

        /* Parser la ligne : id|nom|adresse|specialite|places|horaires */
        char id[50], nom[100], adresse[200], specialite[50], horaires[100];
        int places;

        if (sscanf(line, "%49[^|]|%99[^|]|%199[^|]|%49[^|]|%d|%99[^\n]",
                   id, nom, adresse, specialite, &places, horaires) == 6) {
            Centre *centre = create_centre(id, nom, adresse, specialite, places, horaires);
            add_centre_to_list(&centres, centre);
        }
    }

    fclose(file);
    return centres;
}

/* Sauvegarder les centres dans le fichier */
void save_centres_to_file(GList *centres, const char *filename)
{
    FILE *file = fopen(filename, "w");
    if (!file) {
        g_warning("Impossible d'ouvrir le fichier %s en écriture", filename);
        return;
    }

    for (GList *iter = centres; iter != NULL; iter = iter->next) {
        Centre *centre = (Centre *)iter->data;
        fprintf(file, "%s|%s|%s|%s|%d|%s\n",
                centre->id, centre->nom, centre->adresse,
                centre->specialite, centre->places, centre->horaires);
    }

    fclose(file);
}

/* Créer un nouveau centre */
Centre* create_centre(const char *id, const char *nom, const char *adresse, const char *specialite, int places, const char *horaires)
{
    Centre *centre = (Centre *)malloc(sizeof(Centre));
    if (!centre) return NULL;

    strncpy(centre->id, id, sizeof(centre->id) - 1);
    strncpy(centre->nom, nom, sizeof(centre->nom) - 1);
    strncpy(centre->adresse, adresse, sizeof(centre->adresse) - 1);
    strncpy(centre->specialite, specialite, sizeof(centre->specialite) - 1);
    centre->places = places;
    strncpy(centre->horaires, horaires, sizeof(centre->horaires) - 1);

    return centre;
}

/* Ajouter un centre à la liste */
void add_centre_to_list(GList **centres, Centre *centre)
{
    if (!centres || !centre) return;
    *centres = g_list_append(*centres, centre);
}

/* Supprimer un centre de la liste */
void delete_centre_from_list(GList **centres, const char *id)
{
    if (!centres || !id) return;

    for (GList *iter = *centres; iter != NULL; iter = iter->next) {
        Centre *centre = (Centre *)iter->data;
        if (strcmp(centre->id, id) == 0) {
            *centres = g_list_remove(*centres, centre);
            free(centre);
            return;
        }
    }
}

/* Trouver un centre par ID */
Centre* find_centre_by_id(GList *centres, const char *id)
{
    if (!id) return NULL;

    for (GList *iter = centres; iter != NULL; iter = iter->next) {
        Centre *centre = (Centre *)iter->data;
        if (strcmp(centre->id, id) == 0) {
            return centre;
        }
    }

    return NULL;
}

/* Libérer la liste des centres */
void free_centres_list(GList *centres)
{
    for (GList *iter = centres; iter != NULL; iter = iter->next) {
        free(iter->data);
    }
    g_list_free(centres);
}
