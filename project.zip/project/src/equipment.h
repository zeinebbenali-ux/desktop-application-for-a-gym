#ifndef EQUIPMENT_H
#define EQUIPMENT_H

#include <glib.h>

/* Structure pour un équipement */
typedef struct {
    char id[50];
    char code_barre[100];
    char type[100];
    char marque[100];
    char centre[100];
    char disponibilite[50];
} Equipment;

/* Structure pour une réservation */
typedef struct {
    char id_reservation[50];
    char code_barre[100];
    char id_entraineur[50];
    char jour[50];
    char creneau[50];
    char date[20];
} Reservation;

/* Fonctions CRUD pour équipements */
GList* load_equipments(const char *filepath);
void save_equipments(GList *equipments, const char *filepath);
Equipment* create_equipment(const char *id, const char *code_barre, const char *type,
                           const char *marque, const char *centre, const char *disponibilite);
void free_equipment(Equipment *eq);
void free_equipments_list(GList *equipments);
Equipment* find_equipment_by_code(GList *equipments, const char *code_barre);
Equipment* find_equipment_by_id(GList *equipments, const char *id);

/* Fonctions CRUD pour réservations */
GList* load_reservations(const char *filepath);
void save_reservations(GList *reservations, const char *filepath);
Reservation* create_reservation(const char *id_reservation, const char *code_barre,
                               const char *id_entraineur, const char *jour,
                               const char *creneau, const char *date);
void free_reservation(Reservation *res);
void free_reservations_list(GList *reservations);
gboolean is_equipment_available(GList *reservations, const char *code_barre,
                               const char *jour, const char *creneau);
GList* get_reservations_by_trainer(GList *reservations, const char *id_entraineur);

#endif /* EQUIPMENT_H */
