#ifndef CENTRES_H
#define CENTRES_H

#include <gtk/gtk.h>

/* Structure pour un centre */
typedef struct {
    char id[50];
    char nom[100];
    char adresse[200];
    char specialite[50];
    int places;
    char horaires[100];
} Centre;

/* Fonctions CRUD */
GList* load_centres_from_file(const char *filename);
void save_centres_to_file(GList *centres, const char *filename);
Centre* create_centre(const char *id, const char *nom, const char *adresse, const char *specialite, int places, const char *horaires);
void add_centre_to_list(GList **centres, Centre *centre);
void delete_centre_from_list(GList **centres, const char *id);
Centre* find_centre_by_id(GList *centres, const char *id);
void free_centres_list(GList *centres);

#endif
